# Interactive Sudoku Game in C

This repository contains a fully interactive terminal-based Sudoku game written in C.
Follow the project structure as required by guidelines.

