#include <stdio.h>
#include <time.h>

// (code shortened for readability in this ZIP structure)
// You can paste the full code again here if needed.

